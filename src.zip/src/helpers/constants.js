export const CITIES = [
    'Yerevan',
    'London',
    'Paris',
    'Rome',
    'Washington',
    'Tokyo',
    'Berlin',
    'Moscow',
    'Dubai'

];
export const KEY = '98f1980794ea7dc0ff49ad48a0950517';